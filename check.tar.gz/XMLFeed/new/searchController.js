'use strict';
var searchapp = angular.module('searchapp', ['ngResource']);

searchapp.filter('unsafe', function($sce) {
	return function(val) {
		return $sce.trustAsHtml(val);
	 };
	});


searchapp.controller('searchController', function($scope, $resource) {
	$scope.searchquery = '';
	$scope.result = '';
	
	$scope.doSearch = function(){
		getRes();
	};
	
	/*$scope.keyDown = function(event) {	  
		  if (event.keyCode == 13){
			 getRes();
		  }
	  };*/
	  function getRes(res) {
		  $scope.result='';
         $scope.serviceURL = "http://adsbeta.vertoz.com/txtfeed/search?adunit=VZG671173V0G210G&auth=UV9781812FFG98&subid=test&ua=Mozilla%2F5.0%20%28Windows%20NT%206.1%3B%20WOW64%3B%20rv%3A13.0%29%20Gecko%2F20100101%20Firefox%2F13.0.1&url=http%3A%2F%2Ftest.com%2F%3Fq%3Dbest%2Bdeals&ip=202.171.234.0&query="+$scope.searchquery;
		var xmlhttp=new XMLHttpRequest();
		  xmlhttp.open("GET", $scope.serviceURL,false);
         
          	xmlhttp.send();  
		 var xmlDoc=xmlhttp.responseXML;
          
		 var x=xmlDoc.getElementsByTagName("listing");
          
		 if(x.length == 0){
			document.getElementById("errorMsg").style.display='block'; 
			document.getElementById("errorMsg").innerHTML= "No results found"; 
		 }
		 $scope.setData = [];

		 if(x.length >0){
			 document.getElementById("errorMsg").style.display='none'; 
		
		
		 for (var i=0;i <x.length;i++)
		   { console.log(x[i].getAttribute("descr"));
			 var data={};
			 data.bid= x[i].getAttribute("bid");
            data.descr= x[i].getAttribute("descr");
		    data.site = x[i].getAttribute("site");
		    data.title = x[i].getAttribute("title");
		    data.url = x[i].getAttribute("url");
			   $scope.setData.push(data);
		  
		   }
	  }
		 
	 };
});
