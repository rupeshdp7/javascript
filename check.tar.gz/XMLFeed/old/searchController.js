'use strict';
var searchapp = angular.module('searchapp', ['ngResource']);

searchapp.filter('unsafe', function($sce) {
	return function(val) {
		return $sce.trustAsHtml(val);
	 };
	});


searchapp.controller('searchController', function($scope, $resource) {
	$scope.searchquery = '';
	$scope.result = '';
	
	$scope.doSearch = function(){
		getRes();
	};
	
	/*$scope.keyDown = function(event) {	  
		  if (event.keyCode == 13){
			 getRes();
		  }
	  };*/
	  function getRes(res) {
		  $scope.result='';
         $scope.serviceURL = "http://text.vrtzads.com/textfeed/search?adunit=VZI720132V1329H0&auth=SV5831153DCBE0&subid=test&ua=Mozilla%2F5.0%20%28Windows%20NT%206.1%3B%20WOW64%3B%20rv%3A13.0%29%20Gecko%2F20100101%20Firefox%2F13.0.1&url=http%3A%2F%2Ftest.com%2F%3Fq%3Dbest%2Bdeals&ip=202.171.234.0&query="+$scope.searchquery;
		var xmlhttp=new XMLHttpRequest();
		  xmlhttp.open("GET", $scope.serviceURL,false);
          xmlhttp.onreadystatechange = function (oEvent) {  
    if (xmlhttp.readyState === 4) {  
        if (xmlhttp.status === 200) {  
          console.log(xmlhttp.responseText);  
        } else {  
           console.log("Error", xmlhttp.responseXML);  
        }  
    }  
}; 

          xmlhttp.send(null);  
		 var xmlDoc=xmlhttp.responseXML;
          console.log(xmlDoc);
		 var x=xmlDoc.getElementsByTagName("result");
		 if(x.length == 0){
			document.getElementById("errorMsg").style.display='block'; 
			document.getElementById("errorMsg").innerHTML= "No results found"; 
		 }
		 $scope.setData = [];

		 if(x.length >0){
			 document.getElementById("errorMsg").style.display='none'; 
		console.log("loading");
		
		 for (var i=0;i<10;i++)
		   { 
			 var data={};
			 data.bid= x[i].getElementsByTagName("listing")[0].getAttribute("bid");
            data.descr= x[i].getElementsByTagName("listing")[0].getAttribute("descr");
		    data.site = x[i].getElementsByTagName("listing")[0].getAttribute("site");
		    data.title = x[i].getElementsByTagName("listing")[0].getAttribute("title");
		    data.url = x[i].getElementsByTagName("listing")[0].getAttribute("url");
			   $scope.setData.push(data);
		  
		   }
	  }
		 
	 };
});
