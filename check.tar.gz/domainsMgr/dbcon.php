<?php
mysql_connect("103.14.98.46","root","tAQkP45R");
mysql_select_db("projects_display_version_2") or die(mysql_error());
/*mysql_connect("67.55.118.222","root","C0rnflake921");
mysql_select_db("projects_display_version_2") or die(mysql_error());*/
?>
