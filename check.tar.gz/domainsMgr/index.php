<?php
require "dbcon.php";
$domain = $_SERVER['SERVER_NAME'];
$uri = $_SERVER['REQUEST_URI'];
$referer = $_SERVER['HTTP_REFERER'];

function get_domain($url)
{
  $pieces = parse_url($url);
  $domain = isset($pieces['host']) ? $pieces['host'] : '';
  if (preg_match('/(?P<domain>[a-z0-9][a-z0-9\-]{1,63}\.[a-z\.]{2,6})$/i', $domain, $regs)) {
    return $regs['domain'];
  }
  return false;
}

$refererDomain = get_domain($referer);
$refererDomain = trim($refererDomain);
$date=date("Y-m-d");
$urlParam = explode("?url=", $uri);
$urlParamVal = $urlParam[1];
$urlParamVal = preg_replace("(^https?://)", "", $urlParamVal );
if($urlParamVal != null){
    $finalUrl = "http://".$urlParamVal;                                                                                   
 
?>

<script type="text/javascript">
    var redirectUrl = <?php echo "'".$finalUrl."'" ; ?>;
    window.location=redirectUrl;
    var referal = <?php echo "'".$referer."'" ; ?>;
</script>

<?php

}
/*if($urlParamVal != null){
    
   $query=mysql_query("SELECT domain FROM tbl_domaintable ORDER BY RAND() LIMIT 1") or die(mysql_error());
   $finalUrl = mysql_result($query,0);
    
    $redirectUrl = "http://".$finalUrl."/index.php?url=".$urlParamVal;
   ?>
<script type="text/javascript">
     var redirectUrl = <?php echo "'".$redirectUrl."'" ; ?>;
     console.log(redirectUrl);
    window.location=redirectUrl;
</script>
<?php
    
}*/else{
    $fetchRes=mysql_query("select * from tbl_domaintable where domain = '$refererDomain'");
    $num_rows = mysql_num_rows($fetchRes);
    if ($num_rows==0 ||  trim($refererDomain)!='') {
       /* $sql = mysql_query("insert into  tbl_domaintable(domain,updated,created,status) values('$refererDomain','$date','$date',1)") or die("connection failed while insertion");*/
     }else{
        if(trim($refererDomain)!=''){
        $sql = mysql_query("update tbl_domaintable
        set updated='$date'
        where domain='$refererDomain'") or die("connection failed for updating");
        } 
        
    }
    
?>
<script type="text/javascript">
    
     window.location="http://www.knowledgehigh.com";
</script>

<?php    
    die();
}
?>