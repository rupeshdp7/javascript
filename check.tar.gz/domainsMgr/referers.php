<?php
require "dbcon.php";
 $query=mysql_query("SELECT domain, updated FROM tbl_domaintable") or die(mysql_error());
$num_rows = mysql_num_rows($query);
$table = '<table>';
$count = 1;
 while($row = mysql_fetch_assoc($query))
{      $table=$table.""."<tr><td>".$count."</td><td>";
   $table= $table."".$row['domain']." ";
    $table=$table.""."</td><td>";
    $table=$table."".$row['updated']."";
    $table=$table."</td></tr>";
  $count++;
    
}
$table=$table.""."</table>";
echo $table;
?>



