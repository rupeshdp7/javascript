<?php
require "dbcon.php";
$domain = $_SERVER['SERVER_NAME'];
$uri = $_SERVER['REQUEST_URI'];
$date=date("Y-m-d");
$urlParam = explode("?url=", $uri);
$urlParamVal = $urlParam[1];
$urlParamVal = preg_replace("(^https?://)", "", $urlParamVal );
if($urlParamVal != null){
    $finalUrl = "http://".$urlParamVal;
 /*header("Location: ".$finalUrl);
  die();
   */ 
   
?>

<script type="text/javascript">
    var redirectUrl = <?php echo "'".$finalUrl."'" ; ?>;
    console.log(redirectUrl);
     window.location=redirectUrl;
</script>

<?php

}else{
    
    $fetchRes=mysql_query("select * from tbl_domaintable where domain='$domain'");
    
    if (!$fetchRes) {
        $sql = mysql_query("insert into  tbl_domaintable(domain,updated,created,status) values('$domain','$date','$date',1)") or die("connection failed while insertion");
         
    }else{
        $sql = mysql_query("update tbl_domaintable
        set updated='$date'
        where domain='$domain'") or die("connection failed for updating");
        
    }
    
?>
<script type="text/javascript">
     window.location="http://www.bharatbank.org";
</script>

<?php    
    die();
}
?>