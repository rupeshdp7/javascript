<?php
require "dbcon.php";
$domain = $_SERVER['SERVER_NAME'];
$uri = $_SERVER['REQUEST_URI'];
$urlParam = explode("?url=", $uri);
$urlParamVal = $urlParam[1];
if($urlParamVal != null){
    
   $query=mysql_query("SELECT domain FROM tbl_domaintable ORDER BY RAND() LIMIT 1") or die(mysql_error());
   $finalUrl = mysql_result($query,0);
    
    $redirectUrl = "http://".$finalUrl."?url=".$urlParamVal;
   ?>
<script type="text/javascript">
     var redirectUrl = <?php echo "'".$redirectUrl."'" ; ?>;
    window.location=redirectUrl;
</script>
<?php
    
}else{
    //No param passed. Redirect to ad page.
    ?>
<script type="text/javascript">
      window.location="http://www.knowledgehigh.com";
</script>

<?php
    die();
   
}
?>



