<?php
/**
 * Header template for the theme
 *
 * Displays all of the <head> section and everything up till <div id="main">.
 *
 * @package WordPress
 * @subpackage Business_Board
 * @since Business Board 1.0
 */
?><!DOCTYPE html>
<!--[if IE 6]>
<html id="ie6" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 7]>
<html id="ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html id="ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 6) | !(IE 7) | !(IE 8)  ]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<meta name="viewport" content="width=device-width" />
<title><?php wp_title( '|', true, 'right' ); ?></title>
<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<!--[if lt IE 9]>
<script src="<?php echo get_template_directory_uri(); ?>/js/html5.js" type="text/javascript"></script>
<![endif]-->
<?php
	/*
	 * We add some JavaScript to pages with the comment form
	 * to support sites with threaded comments (when in use).
	 */
	if ( is_singular() && get_option( 'thread_comments' ) )
		wp_enqueue_script( 'comment-reply' );

	/*
	 * Always have wp_head() just before the closing </head>
	 * tag of your theme, or you will break many plugins, which
	 * generally use this hook to add elements to <head> such
	 * as styles, scripts, and meta tags.
	 */
	wp_head();
?>

<script>

jQuery(document).ready(function(){
	jQuery( ".square_post .post-title" ).after( "<span></span>" );
	jQuery( ".category .hentry .entry-content" ).after( "<span class='patch'></span>" );  
	jQuery( ".linksalpha_widget" ).remove();
	
});

</script>

<script src='https://s.yimg.com/uv/dm/scripts/syndication.js'></script>
</head>

<body <?php body_class(); ?> class="bg_menu">
<!--<div class="topbar">
      <div class="ctnr">
      	<div class="txrt">
        	<a href="http://strongbusinessideas.com/" target="_blank"><img src="<?php echo get_bloginfo('template_directory');?>/images/logo-1.png"></a>
<a href="http://financegoahead.com" target="_blank"><img src="<?php echo get_bloginfo('template_directory');?>/images/logo-2.png"></a>
<img src="<?php echo get_bloginfo('template_directory');?>/images/logo-3.png">
<a href="http://definingbusiness.com" target="_blank"><img src="<?php echo get_bloginfo('template_directory');?>/images/logo-4.png"></a>
        </div>
      </div>
  </div>-->
<!--BEGIN ANDBEYOND TAG -->
<script data-cfasync='false' type='text/javascript'>
	if (window.location.hash.indexOf('apdAdmin')!= -1){if(typeof(Storage) !== 'undefined' && localStorage !== null) {localStorage.apdAdmin = 1;}}
	var adminMode = ((typeof(Storage) == 'undefined'  || localStorage === null) || (localStorage.apdAdmin == 1));
	window.apd_options = {
	 "accelerate": 0,
	 "dynamicElements": 1,
	 "websiteId": 5470
	};
	(function() {
		var apd = document.createElement('script'); apd.type = 'text/javascript'; apd.async = true;
		if(adminMode){
			apd.src = 'https://ecdn.andbeyond.media/apd.js?id=' + apd_options.websiteId;
		}
		else{
			apd.src = (('https:' == document.location.protocol || window.parent.location != window.location) ? 'https://' : 'http://') + 'ecdn.andbeyond.media/apd_client.js';
		}
		var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(apd, s);
	})();
</script>
<!-- END ANDBEYOND TAG -->
<div id="page" class="hfeed">
<div class="socialbar">
                      <?php if ( is_active_sidebar( 'social_icons' ) ) : ?>
                      <?php dynamic_sidebar( 'social_icons' ); ?>
                      <?php endif; ?>
                      <div class="srch" style="display:none;">

			<?php get_search_form(); ?>
			</div>
                    </div>
	<header id="branding" role="banner">
			<div class="logo">
				<div id="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home">
                	<img alt="" src="<?php bloginfo('template_directory')?>/images/logo.png"/>
                </a>
                	 
                </div>				
			</div>

			<nav id="access" role="navigation">
		
				<?php /* Allow screen readers / text browsers to skip the navigation menu and get right to the good stuff. */ ?>
				<div class="skip-link"><a class="assistive-text" href="#content" title="<?php esc_attr_e( 'Skip to primary content', 'businessboard' ); ?>"><?php _e( 'Skip to primary content', 'businessboard' ); ?></a></div>
				<div class="skip-link"><a class="assistive-text" href="#secondary" title="<?php esc_attr_e( 'Skip to secondary content', 'businessboard' ); ?>"><?php _e( 'Skip to secondary content', 'businessboard' ); ?></a></div>
				<?php /* Our navigation menu. If one isn't filled out, wp_nav_menu falls back to wp_page_menu. The menu assigned to the primary location is the one used. If one isn't assigned, the menu with the lowest ID is used. */ ?>
				<?php wp_nav_menu( array( 'theme_location' => 'primary' ) ); ?>
			</nav><!-- #access -->
	</header><!-- #branding -->
  <div class="topslider">
  	<?php if ( is_active_sidebar( 'top_slider' ) ) : ?>
    <?php dynamic_sidebar( 'top_slider' ); ?>
    <?php endif; ?>
  </div>
  
  <div class="thumbslider">
  	<?php if ( is_active_sidebar( 'thumb_slider' ) ) : ?>
    <?php dynamic_sidebar( 'thumb_slider' ); ?>
    <?php endif; ?>
  </div>
  
  <div class="width1080">
  	<?php if ( is_active_sidebar( 'header_ad' ) ) : ?>
    <?php dynamic_sidebar( 'header_ad' ); ?>
    <?php endif; ?>
  </div>
<?php if(is_front_page()) { ?>
<?php } else { ?>
	<div class="breadcrumbs">
    <?php if(function_exists('bcn_display'))
    {
        bcn_display();
    }?>
</div>
<?php } ?>

	<div id="main">