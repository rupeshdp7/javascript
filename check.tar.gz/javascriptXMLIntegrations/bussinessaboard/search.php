<?php
/**
 * Template for displaying all single posts
 *
 * @package WordPress
 * @subpackage Business_Board
 * @since Business Board 1.0
 */

get_header(); ?>

<div id="primary">
			<div id="content" role="main">
 <style>#ypaAdWrapper-Search iframe{width:100%}</style>
                   <div id="ypaAdWrapper-Search"></div>
                
                
<?php echo do_shortcode('[CBC show="y" country="mx"]
 
         
<!--Insert the code below after any div.-->
    
<script type="text/javascript">
                        window.ypaAds.insertMultiAd({
                            ypaAdConfig   : "0000004a9",
                            ypaAdTypeTag  : "479",
                            ypaAdSlotInfo : [ 
                                {
                                    ypaAdSlotId : "Search",
                                    ypaAdDivId  : "ypaAdWrapper-Search",
                                    ypaAdWidth  : "600",
                                    ypaAdHeight : "996"
                                },
                            ]   
                        }); 
    
</script>

            [/CBC]'.'[CBC show="y" country="ve"]
 
          
<!--Insert the code below after any div.-->
  
<script type="text/javascript">
                        window.ypaAds.insertMultiAd({
                            ypaAdConfig   : "000000501",
                            ypaAdTypeTag  : "481",
                            ypaAdSlotInfo : [ 
                                {
                                    ypaAdSlotId : "Search",
                                    ypaAdDivId  : "ypaAdWrapper-Search",
                                    ypaAdWidth  : "600",
                                    ypaAdHeight : "996"
                                },
                            ]   
                        }); 
    
</script>

            [/CBC]'.'[CBC show="y" country="pe"]
 
          
<!--Insert the code below after any div.-->
    
<script type="text/javascript">
                        window.ypaAds.insertMultiAd({
                            ypaAdConfig   : "0000004fd",
                            ypaAdTypeTag  : "482",
                            ypaAdSlotInfo : [ 
                                {
                                    ypaAdSlotId : "Search",
                                    ypaAdDivId  : "ypaAdWrapper-Search",
                                    ypaAdWidth  : "600",
                                    ypaAdHeight : "996"
                                },
                            ]   
                        }); 
    
</script>

            [/CBC]'.'[CBC show="y" country="co"]
 
          
<!--Insert the code below after any div.-->
    
<script type="text/javascript">
                        window.ypaAds.insertMultiAd({
                            ypaAdConfig   : "0000004f9",
                            ypaAdTypeTag  : "483",
                            ypaAdSlotInfo : [ 
                                {
                                    ypaAdSlotId : "Search",
                                    ypaAdDivId  : "ypaAdWrapper-Search",
                                    ypaAdWidth  : "600",
                                    ypaAdHeight : "996"
                                },
                            ]   
                        }); 
    
</script>

            [/CBC]'.'[CBC show="y" country="cl"]
 
          
<!--Insert the code below after any div.-->
   
<script type="text/javascript">
                        window.ypaAds.insertMultiAd({
                            ypaAdConfig   : "0000004f5",
                            ypaAdTypeTag  : "484",
                            ypaAdSlotInfo : [ 
                                {
                                    ypaAdSlotId : "Search",
                                    ypaAdDivId  : "ypaAdWrapper-Search",
                                    ypaAdWidth  : "600",
                                    ypaAdHeight : "996"
                                },
                            ]   
                        }); 
    
</script>

            [/CBC]'.'[CBC show="y" country="br"]
             <style>#ypaAdWrapper-Search iframe{width:100%}</style>
            <script type="text/javascript">
                        window.ypaAds.insertMultiAd({
                            ypaAdConfig   : "000000521",
                            ypaAdTypeTag  : "",
                            ypaAdSlotInfo : [ 
                                {
                                    ypaAdSlotId : "Search",
                                    ypaAdDivId  : "ypaAdWrapper-Search",
                                    ypaAdWidth  : "600",
                                    ypaAdHeight : "1002"
                                }
                            ]   
                        }); 
</script>[/CBC]'.'[CBC show="n" country="mx, ve, pe, co, cl, br"]
 
         
<!--Insert the code below after any div.-->
    
<script type="text/javascript">
                        window.ypaAds.insertMultiAd({
                            ypaAdConfig   : "0000004a9",
                            ypaAdTypeTag  : "",
                            ypaAdSlotInfo : [ 
                                {
                                    ypaAdSlotId : "Search",
                                    ypaAdDivId  : "ypaAdWrapper-Search",
                                    ypaAdWidth  : "600",
                                    ypaAdHeight : "996"
                                },
                            ]   
                        }); 
    
</script>

            [/CBC]') ?>
                
                

			</div><!-- #content -->
		</div><!-- #primary -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>