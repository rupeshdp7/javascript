<?php 
error_reporting(0);
function decodeParam($s) {
	if ($s && get_magic_quotes_gpc())
		return stripslashes($s);
	else
		return $s;
}

function noCacheHeaders() {
	header("Cache-Control: no-store");
	header("Pragma: no-cache");
	header("Age: 0");
}

$ads =get_search_query();



if ($ads)
{
	
$rtype="xml";
$key="qeqsw";
$subid="108";
$fid="10029";

$ip=$_SERVER['REMOTE_ADDR'];
$ua=$_SERVER['HTTP_USER_AGENT'];
$results="6";


$url = "http://xml.adfeeds.net:80/?key=$key&subid=$subid&fid=$fid&kw=$ads&ip=$ip&ua=$ua&results=$results&rtype=$rtype";

//$url = "http://xml.adfeeds.net:8080/?key=$key&subid=$subid&fid=$fid&kw=$ads&ip=$ip&ua=$ua&results=$results&rtype=$rtype";


//print $url;

$data=simplexml_load_file($url);


#echo "<pre>"; print_r($data); echo "</pre>";
$title=$data->adlisting->adtitle;
$addescr=$data->adlisting->addescr;
$adsite=$data->adlisting->adsite;
$i=1;
foreach($data as $v)
{

$title=$v->adtitle;
$addescr=$v->addescr;
$adsite=$v->adsite;
$adurl=$v->adclickurl;
if($i<=3)
{
$top_ads[] = "<a href='" . $adurl . "' target='_blank'><div class='vz_ad_div'><div class='vz_ad_title'>". strip_tags($title) . "</div><div class='vz_ad_desc'>". strip_tags($addescr) . "</div><div class='vz_ad_url'>" . $adsite. "</div></div></a>";
$i++;
}
else
{
$bottom_ads[]  = "<a href='" . $adurl . "' target='_blank'><div class='vz_ad_div'><div class='vz_ad_title'>". strip_tags($title) . "</div><div class='vz_ad_desc'>". strip_tags($addescr) . "</div><div class='vz_ad_url'>" . $adsite. "</div></div></a>";
$i++;
}
}
}
get_header();


 ?>
<style>
		.vz_ads_div {background: none repeat scroll 0 0 #F8F7F7;border: 1px solid #E4E4E4;margin: 0 0 10px;font-family: CartoGothicStd-Book;src: url(CartoGothicStd-Book.otf);}
		.vz_ads_div a {	text-decoration: none;}
		.vz_heading {color: #494949;font-size: 11px;padding:10px 10px 0;}
		.vz_ad_div {padding: 10px;}
		.vz_ad_title {color: #E56C69;font-size: 18px;text-decoration: underline;}
		.vz_ad_desc {color: #3D3D3D;font-size: 12px;}
		.vz_ad_url {color: #467305;font-size: 11pt;}
		.related_word {padding:10px;color:#3d3d3d;}
		.related_word span {color:#e56c69;font-size:15px;}
		.related_word a {color:#e56c69;font-size:15px;}
		.related_word a:hover {color: #AC3633;}
		
		
</style>
<!--INFOLINKS_OFF-->
<div id="container">
	<div id="content" role="main">
        <div id="ypaAdWrapper-Search"></div>
        <?php echo do_shortcode('[CBC show="y" country="mx"]
 
         
<!--Insert the code below after any div.-->
    
<script type="text/javascript">
                        window.ypaAds.insertMultiAd({
                            ypaAdConfig   : "0000004a9",
                            ypaAdTypeTag  : "479",
                            ypaAdSlotInfo : [ 
                                {
                                    ypaAdSlotId : "Search",
                                    ypaAdDivId  : "ypaAdWrapper-Search",
                                    ypaAdWidth  : "600",
                                    ypaAdHeight : "996"
                                },
                            ]   
                        }); 
    
</script>

            [/CBC]'.'[CBC show="y" country="ve"]
 
          
<!--Insert the code below after any div.-->
  
<script type="text/javascript">
                        window.ypaAds.insertMultiAd({
                            ypaAdConfig   : "0000004a9",
                            ypaAdTypeTag  : "481",
                            ypaAdSlotInfo : [ 
                                {
                                    ypaAdSlotId : "Search",
                                    ypaAdDivId  : "ypaAdWrapper-Search",
                                    ypaAdWidth  : "600",
                                    ypaAdHeight : "996"
                                },
                            ]   
                        }); 
    
</script>

            [/CBC]'.'[CBC show="y" country="pe"]
 
          
<!--Insert the code below after any div.-->
    
<script type="text/javascript">
                        window.ypaAds.insertMultiAd({
                            ypaAdConfig   : "0000004a9",
                            ypaAdTypeTag  : "482",
                            ypaAdSlotInfo : [ 
                                {
                                    ypaAdSlotId : "Search",
                                    ypaAdDivId  : "ypaAdWrapper-Search",
                                    ypaAdWidth  : "600",
                                    ypaAdHeight : "996"
                                },
                            ]   
                        }); 
    
</script>

            [/CBC]'.'[CBC show="y" country="co"]
 
          
<!--Insert the code below after any div.-->
    
<script type="text/javascript">
                        window.ypaAds.insertMultiAd({
                            ypaAdConfig   : "0000004a9",
                            ypaAdTypeTag  : "483",
                            ypaAdSlotInfo : [ 
                                {
                                    ypaAdSlotId : "Search",
                                    ypaAdDivId  : "ypaAdWrapper-Search",
                                    ypaAdWidth  : "600",
                                    ypaAdHeight : "996"
                                },
                            ]   
                        }); 
    
</script>

            [/CBC]'.'[CBC show="y" country="cl"]
 
          
<!--Insert the code below after any div.-->
   
<script type="text/javascript">
                        window.ypaAds.insertMultiAd({
                            ypaAdConfig   : "0000004a9",
                            ypaAdTypeTag  : "484",
                            ypaAdSlotInfo : [ 
                                {
                                    ypaAdSlotId : "Search",
                                    ypaAdDivId  : "ypaAdWrapper-Search",
                                    ypaAdWidth  : "600",
                                    ypaAdHeight : "996"
                                },
                            ]   
                        }); 
    
</script>

            [/CBC]'.'[CBC show="y" country="br"]

            <style>#ypaAdWrapper-Search iframe{width:100%}</style>
 <div id="ypaAdWrapper-Search"></div>
    
<script type="text/javascript">
                        window.ypaAds.insertMultiAd({
                            ypaAdConfig   : "0000004a9",
                            ypaAdTypeTag  : "",
                            ypaAdSlotInfo : [ 
                                {
                                    ypaAdSlotId : "Search",
                                    ypaAdDivId  : "ypaAdWrapper-Search",
                                    ypaAdWidth  : "600",
                                    ypaAdHeight : "996"
                                },
                            ]   
                        }); 
    
</script>

            [/CBC]'.'[CBC show="n"  country="mx, ve, pe, co, cl, br"]
 
         
<!--Insert the code below after any div.-->
    
<script type="text/javascript">
                        window.ypaAds.insertMultiAd({
                            ypaAdConfig   : "0000004a9",
                            ypaAdTypeTag  : "479",
                            ypaAdSlotInfo : [ 
                                {
                                    ypaAdSlotId : "Search",
                                    ypaAdDivId  : "ypaAdWrapper-Search",
                                    ypaAdWidth  : "600",
                                    ypaAdHeight : "996"
                                },
                            ]   
                        }); 
    
</script>

            [/CBC]') ?>
        
        
    <!--INFOLINKS_OFF-->
    <?php
    if(isset($top_ads))
	{
		echo "<div class='vz_ads_div'>";
		echo "<div class='vz_heading'>Sponsored Listing</div>";				
		foreach ($top_ads as $ad)
		{
			echo $ad;
		}
		echo  "</div>";

	}
	else {
		
		if($location_array->country_code =="US")
		{
		echo '<div class="vz_ads_div"><vc:block data-term="'.$query.'" data-affId="189890" data-listings="4" data-stylesheet="http://howgeneric.com/master.css"></vc:block></div>';
		}	
	}
	?>
    <!--INFOLINKS_ON-->
    <?php		
		
		 if ( have_posts() ) : ?>
				<h1 class="page-title"><?php printf( __( 'Search Results for: %s', 'howgeneric' ), '<span>' . get_search_query() . '</span>' ); ?></h1>
				<?php
				/* Run the loop for the search to output the results.
				 * If you want to overload this in a child theme then include a file
				 * called loop-search.php and that will be used instead.
				 */
				 get_template_part( 'loop', 'search' );
				?>
				<?php else : ?>
				<div id="post-0" class="post no-results not-found">
					<h2 class="entry-title"><?php _e( 'Nothing Found', 'howgeneric' ); ?></h2>
					<div class="entry-content">
						<p><?php _e( 'Sorry, but nothing matched your search criteria. Please try again with some different keywords.', 'howgeneric' ); ?></p>
						<?php get_search_form(); ?>
					</div><!-- .entry-content -->
				</div><!-- #post-0 -->
				<?php endif; ?>
                <!--INFOLINKS_OFF-->
                <?php
				if(isset($bottom_ads))
				{
				 	echo "<div class='vz_ads_div'>";
					echo "<div class='vz_heading'>Sponsored Listing</div>";				
					foreach ($bottom_ads as $ad)
					{
						echo $ad;
					}
					echo  "</div>";

				}
				else {
						if($location_array->country_code =="US")
						{
							echo '<div class="vz_ads_div"><vc:block data-term="'.$query.'" data-affId="189890" data-listings="4" data-stylesheet="http://howgeneric.com/master.css"></vc:block></div>';
						}	

				}
				?>
                <!--INFOLINKS_ON-->
			</div><!-- #content -->
		</div><!-- #container -->
<script src="http://feed.validclick.com/js/validclick-master.js"></script>
<?php get_sidebar(); ?>
<?php get_footer(); ?>