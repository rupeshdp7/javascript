'use strict';
var searchapp = angular.module('searchapp', ['ngResource']);

searchapp.filter('unsafe', function($sce) {
	return function(val) {
		return $sce.trustAsHtml(val);
	 };
	});


searchapp.controller('searchController', function($scope, $resource) {
	$scope.searchquery = '';
	$scope.result = '';
	
	$scope.doSearch = function(){
		getRes();
	};
	
	$scope.keyDown = function(event) {	  
		  if (event.keyCode == 13){
			 getRes();
		  }
	  };
	  function getRes(res) {
		  $scope.result='';
		  $scope.serviceURL ="http://api.wtpn.twenga.com/v2.1/search/offer?cack=2fbadb3096fb3a5386bfee279c460cea8a6e08ee&confkey=5267c9de76e5a&e=eyJrIjoiNTI1ZWFmNGViNmYwMSIsImMiOiI1IiwibCI6IjE1IiwibyI6InhtbCJ9&subid=s123456&nb_results=10%20%5B6/2/2015%208:18:13%20PM%5D%20http://discountmyprice.com/search_products.htm?searchWithin=&&searchText=cricket&btnGo.x=0&btnGo.y=0&keyword="+$scope.searchquery;
		var xmlhttp=new XMLHttpRequest();
		  xmlhttp.open("GET",$scope.serviceURL,false);
		  xmlhttp.send();
		 var xmlDoc=xmlhttp.responseXML;
		 var x=xmlDoc.getElementsByTagName("result");
		 if(x.length == 0){
			document.getElementById("errorMsg").style.display='block'; 
			document.getElementById("errorMsg").innerHTML= "No results found"; 
		 }
		 $scope.setData = [];
		 if(x.length >0){
			 document.getElementById("errorMsg").style.display='none'; 
		console.log("loading");
		
		 for (var i=0;i<10;i++)
		   { 
			 var data={};
			 data.image= (x[i].getElementsByTagName("image")[0].getElementsByTagName("small")[0].getElementsByTagName("url")[0].childNodes[0].nodeValue);
		    data.click_url = (x[i].getElementsByTagName("click_url")[0].childNodes[0].nodeValue);
		    data.category = (x[i].getElementsByTagName("category")[0].getElementsByTagName("name")[0].childNodes[0].nodeValue);
		    data.description = (x[i].getElementsByTagName("description")[0].childNodes[0].nodeValue);
		    data.base_price = (x[i].getElementsByTagName("price")[0].childNodes[0].nodeValue);
		    data.shipping = (x[i].getElementsByTagName("shipping_cost")[0].childNodes[0].nodeValue);
			   $scope.setData.push(data);
		  
		   }
	  }
		 
	 };
});
