'use strict';
var searchapp = angular.module('searchapp', ['ngResource']);

searchapp.filter('unsafe', function($sce) {
	return function(val) {
		return $sce.trustAsHtml(val);
	 };
	});


searchapp.controller('searchController', function($scope, $resource) {
	$scope.searchquery = '';
	$scope.result = '';
	
	$scope.doSearch = function(){
		getRes();
	};
	
	$scope.keyDown = function(event) {	  
		  if (event.keyCode == 13){
			 getRes();
		  }
	  };
	  function getRes(res) {
          $("#data").html("");
          $("#myFrame").remove();
		  $scope.result='';
		  $scope.serviceURL ="http://apigslb.superpages.com/xml/search?L=Dallas+TX&STYPE=S&Results=PPC&SRC=exampleppc&PS=3&Search=Find+It&IP=32.32.32.32&C="+$scope.searchquery;
        
         
       
         // Create an iframe element
$('<iframe />', { id: 'myFrame',  width:'100%',  height:'1000', frameBorder : 0, src: $scope.serviceURL }).appendTo('body');
var iframe = document.getElementById("myFrame");
var iframe_contents = $("#myFrame").contents();
          console.log(iframe_contents);
          var ifram = iframe_contents.find('body').html();
     // $("#myFrame").css("display", "none");
          $("#data").html(ifram);
         // $("#myFrame").html();
		 console.log(ifram);
		
		 
	 };
});
