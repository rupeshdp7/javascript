'use strict';
var searchapp = angular.module('searchapp', ['ngResource']);

searchapp.filter('unsafe', function($sce) {
	return function(val) {
		return $sce.trustAsHtml(val);
	 };
	});


searchapp.controller('searchController', function($scope, $resource) {
	$scope.searchquery = '';
	$scope.result = '';


	console.log($scope.fullname);
	$scope.doSearch = function(){
		getRes();
	};
	
	$scope.keyDown = function(event) {	  
		  if (event.keyCode == 13){
			 getRes();
		  }
	  };
	  function getRes(res) {
		  $scope.result='';
		  $scope.serviceURL ="http://feed.advertiseclick.com/feed.cgi?aff=31716&auth=eee9bf20&saff=123456&num=10&ip=65.66.66.66&ref=http%3A%2F%2Ftest.com%2F%3Fq%3Dbest%2Bdeals&ua=Mozilla%2F5.0+%28Windows+NT+6.1%3B+WOW64%3B+rv%3A13.0%29+Gecko%2F20100101+Firefox%2F13.0.1&lang=&terms="+$scope.searchquery;
		var xmlhttp=new XMLHttpRequest();
		  xmlhttp.open("GET",$scope.serviceURL,false);
		  xmlhttp.send();
		 var xmlDoc=xmlhttp.responseXML;
		 var x=xmlDoc.getElementsByTagName("result");
		 if(x.length == 0){
			document.getElementById("errorMsg").style.display='block'; 
			document.getElementById("errorMsg").innerHTML= "No results found"; 
		 }
		 $scope.setData = [];
		 if(x.length >0){
			 document.getElementById("errorMsg").style.display='none'; 
		console.log("loading");
		
		 for (var i=0;i<10;i++)
		   { 
			 var data={};
			 data.image= (x[i].getElementsByTagName("image")[0].getElementsByTagName("small")[0].getElementsByTagName("url")[0].childNodes[0].nodeValue);
		    data.click_url = (x[i].getElementsByTagName("click_url")[0].childNodes[0].nodeValue);
		    data.category = (x[i].getElementsByTagName("category")[0].getElementsByTagName("name")[0].childNodes[0].nodeValue);
		    data.description = (x[i].getElementsByTagName("description")[0].childNodes[0].nodeValue);
		    data.base_price = (x[i].getElementsByTagName("price")[0].childNodes[0].nodeValue);
		    data.shipping = (x[i].getElementsByTagName("shipping_cost")[0].childNodes[0].nodeValue);
			   $scope.setData.push(data);
		  
		   }
	  }
		 
	 };
});
