<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>

<head>

    <meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />

    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">



    <title><?php ui::title(); ?></title>



	<link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_url'); ?>" media="screen" />

    

    <link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php ui::rss(); ?>" />

    <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />



    <?php ui::head(); ?>

<!--edomz code start-->

  <script type="text/javascript"><!--

ps_aid = 46024;

ps_website_id = 45566;

ps_ad_cap = 0;

ps_ad_open = 1;

ps_ad_type = 3;

ps_page_url = document.location;

-->

</script>

<script type="text/javascript" src="http://www.edomz.net/popup.js"></script>

<!--edomz code end-->

<script src='https://s.yimg.com/uv/dm/scripts/syndication.js'></script>

 <script type="text/javascript">

     function doSearch(){

      //  query = document.getElementById("s").value;

        //document.getElementById("ypaAdWrapper-Search").innerHTML =  query;

    };

    </script>

</head>

<body <?php body_class() ?>>



<div id="container">



	<div id="pre-header">

		<div class="wrapper">

			<?php if (option::get('menu_top_show') == 'on') { 

				if (has_nav_menu( 'secondary' )) { 

					wp_nav_menu( array('container' => '', 'container_class' => '', 'menu_class' => '', 'menu_id' => '', 'sort_column' => 'menu_order', 'depth' => '1', 'theme_location' => 'secondary' ) );

				}

				else

				{

					echo '<ul><li>Please set your Top Menu on the <a href="'.get_admin_url().'nav-menus.php">Appearance > Menus</a> page or disable it from the <a href="'.get_admin_url().'admin.php?page=wpzoom_options">WPZOOM Theme Options</a> page, General tab.</li></ul>';

				}

			} // if menu top show 

			?>

			<?php if (option::get('social_icons_show') == 'on') { ?>

			<ul id="social-links">

				<li class="list-title"><?php _e('Stay Connected','wpzoom');?></li>

				<?php if (option::get('social_icons_facebook')) { ?><li><a target="_blank" href="<?php echo option::get('social_icons_facebook'); ?>" rel="external,nofollow"><img src="<?php bloginfo('template_url'); ?>/images/icons/ic_facebook.png" width="" height="" alt="Follow Us on Facebook" /></a></li><?php } ?>

				<?php if (option::get('social_icons_twitter')) { ?><li><a target="_blank" href="<?php echo option::get('social_icons_twitter'); ?>" rel="external,nofollow"><img src="<?php bloginfo('template_url'); ?>/images/icons/ic_twitter.png" width="" height="" alt="Follow Us on Twitter" /></a></li><?php } ?>

                 <li><a target="_blank" href="http://pinterest.com/whatisall/"><img src="http://passets-lt.pinterest.com/images/about/buttons/small-p-button.png" width="16" height="16" alt="Follow Me on Pinterest" /></a></li>

				<?php if (option::get('social_icons_youtube')) { ?><li><a target="_blank" href="<?php echo option::get('social_icons_youtube'); ?>" rel="external,nofollow"><img src="<?php bloginfo('template_url'); ?>/images/icons/ic_youtube.png" width="" height="" alt="Follow Us on Youtube" /></a></li><?php } ?>

				<li><a target="_blank" href="<?php ui::rss(); ?>"><img src="<?php bloginfo('template_url'); ?>/images/icons/ic_rss.png" width="" height="" alt="Follow Us on RSS" /></a></li>

                

                <li><a target="_blank" href="http://www.linkedin.com/groups/Whatisall-4236969"><img src="<?php bloginfo('template_url'); ?>/images/icons/ic_linked.png" width="16" height="16" alt="Follow Us on Linkedin" /></a></li>

               

			</ul><!-- end #social-links -->

			<?php } ?>

		</div><!-- end .wrapper -->

	</div><!-- end #pre-header -->

	

	<header id="header">

		<div class="wrapper">



			<div id="logo">

				<a href="<?php echo home_url('/'); ?>"><img src="<?php 

				if (!option::get('misc_logo_path')) 

				{ 

					if (option::get('theme_style') == 'Light')

					{

						echo get_template_directory_uri() . '/images/logo-light.png';

					}

					else {

						echo ui::logo();

					} 

				}

				else {

					echo ui::logo();

				}

				?>" alt="<?php bloginfo('name'); ?>" /></a>

			</div><!-- end #logo -->



			<?php if (option::get('banner_header_enable') == 'on') { ?>

			<div class="header-banner">

					

				<?php if ( option::get('banner_header_html') <> "") { 

					echo stripslashes(option::get('banner_header_html'));             

				} else { ?>

					<a href="<?php echo option::get('banner_header_url'); ?>" rel="nofollow" title="<?php echo option::get('banner_header_alt'); ?>"><img src="<?php echo option::get('banner_header'); ?>" alt="<?php echo option::get('banner_header_alt'); ?>" /></a>

				<?php } ?>		   	

							

			</div><!-- end .header-banner -->

			<?php } ?>

			

			<div class="cleaner">&nbsp;</div>



		</div><!-- end .wrapper -->

		

		<nav id="header-menu">

		

			<div class="wrapper">

			

				<?php if (has_nav_menu( 'primary' )) { 

					wp_nav_menu( array('container' => '', 'container_class' => '', 'menu_class' => 'dropdown', 'menu_id' => 'main-menu', 'sort_column' => 'menu_order', 'theme_location' => 'primary' ) );

				}

				else

				{

					echo '<p>Please set your Main Menu on the <a href="'.get_admin_url().'nav-menus.php">Appearance > Menus</a> page. For more information please <a href="http://www.wpzoom.com/documentation/morning/">read the documentation</a>.</p>';

				}

				?>

			

			</div><!-- end .wrapper -->

		

		</nav>

		

	</header><!-- end header -->

	

	<section id="main">