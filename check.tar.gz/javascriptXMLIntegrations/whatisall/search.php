<style type="text/css">
#wideTopVCblock{
background: none repeat scroll 0 0 #FFFBEA;
border: 1px solid #EFE9D1!important;
}
#wideTopVCblock > a:hover {	text-decoration: none!important;}

.adsByDisclaimer{
color: #494949!important;
font-size: 11px!important;
font-weight: bold!important;
padding:10px 10px 0!important;
}
.adContainer{
padding:10px!important;
}
.title-wrap{
color: #CC333F!important;
font-size:18px!important;
text-decoration:underline!important;
}
.sitehost-wrap{
color: #467305!important;
font-size: 11pt;
}

.description-wrap{
color: #3D3D3D!important;
font-size: 12px!important;
padding: 10px 0!important;
}

</style>
<?php 

require_once './feed/callFeed.php';
$country = getCountryByIpAddress($_SERVER['REMOTE_ADDR']);

$allowedCountries = array('my', 'vn', 'th', 'ph', 'id', 'sg', 'in');
if (in_array($country, $allowedCountries))
{
		$mkt = $country;
}
else 
{
	$mkt ='';
}


get_header();
if ($query = get_search_query())
{
	if($mkt !='')
	{
		$ads = callFeed($query,'','','',6,'', '', 'fromsearchbox'); 
	}	
	?>
    <style type="text/css">
	.vz_ads_div {background: none repeat scroll 0 0 #FFFBEA;border: 1px solid #EFE9D1;}
	.vz_ads_div > a:hover {	text-decoration: none;}
	.vz_heading {color: #494949;font-size: 11px;font-weight: bold;padding:10px 10px 0;}
	.vz_ad_div {padding: 10px;}
	.vz_ad_title {color: #CC333F;font-size: 18px;text-decoration: underline;}
	.vz_ad_desc {color: #3D3D3D;font-size: 12px;padding: 10px 0;}
	.vz_ad_url {color: #467305;font-size: 11pt;}
	.related_word {padding:10px;color:#3d3d3d;}
	.related_word span {color:#e56c69;font-size:15px;}
	.related_word a {color:#e56c69;font-size:15px;}
	.related_word a:hover {color: #AC3633;}
	</style>
    
    <?php
	if ($ads)
	{
		$i=1;
		foreach($ads as $ad)
		{
			if($i<=3)
			{
				$top_ads[] = "<a href='" . $ad[AD_URL] . "' target='_blank'><div class='vz_ad_div'><div class='vz_ad_title'>". strip_tags($ad[AD_TITLE]) . "</div><div class='vz_ad_desc'>". strip_tags($ad[AD_DESCRIPTION]) . "</div><div class='vz_ad_url'>" . $ad[AD_SITE] . "</div></div></a>";
				$i++;
			}				
			else if($i >= 4)	
			{
				$bottom_ads[] = "<a href='" . $ad[AD_URL] . "' target='_blank'><div class='vz_ad_div'><div class='vz_ad_title'>". strip_tags($ad[AD_TITLE]) . "</div><div class='vz_ad_desc'>". strip_tags($ad[AD_DESCRIPTION]) . "</div><div class='vz_ad_url'>" . $ad[AD_SITE] . "</div></div></a>";
				$i++;
			}
		}
	}
	
	
}
?>
<div class="wrapper">
<!--INFOLINKS_OFF-->
	<div id="content">
         <style>#ypaAdWrapper-Search iframe{width:100%}</style>
 <div id="ypaAdWrapper-Search"></div>
        <?php echo do_shortcode('[CBC show="y" country="mx"]
 
         
<!--Insert the code below after any div.-->
    
<script type="text/javascript">
                        window.ypaAds.insertMultiAd({
                            ypaAdConfig   : "0000004f3",
                            ypaAdTypeTag  : "461",
                            ypaAdSlotInfo : [ 
                                {
                                    ypaAdSlotId : "Search",
                                    ypaAdDivId  : "ypaAdWrapper-Search",
                                    ypaAdWidth  : "600",
                                    ypaAdHeight : "996"
                                },
                            ]   
                        }); 
    
</script>

            [/CBC]'.'[CBC show="y" country="ve"]
 
          
<!--Insert the code below after any div.-->
  
<script type="text/javascript">
                        window.ypaAds.insertMultiAd({
                            ypaAdConfig   : "000000503",
                            ypaAdTypeTag  : "463",
                            ypaAdSlotInfo : [ 
                                {
                                    ypaAdSlotId : "Search",
                                    ypaAdDivId  : "ypaAdWrapper-Search",
                                    ypaAdWidth  : "600",
                                    ypaAdHeight : "996"
                                },
                            ]   
                        }); 
    
</script>

            [/CBC]'.'[CBC show="y" country="pe"]
 
          
<!--Insert the code below after any div.-->
    
<script type="text/javascript">
                        window.ypaAds.insertMultiAd({
                            ypaAdConfig   : "0000004ff",
                            ypaAdTypeTag  : "464",
                            ypaAdSlotInfo : [ 
                                {
                                    ypaAdSlotId : "Search",
                                    ypaAdDivId  : "ypaAdWrapper-Search",
                                    ypaAdWidth  : "600",
                                    ypaAdHeight : "996"
                                },
                            ]   
                        }); 
    
</script>

            [/CBC]'.'[CBC show="y" country="co"]
 
          
<!--Insert the code below after any div.-->
    
<script type="text/javascript">
                        window.ypaAds.insertMultiAd({
                            ypaAdConfig   : "0000004fb",
                            ypaAdTypeTag  : "465",
                            ypaAdSlotInfo : [ 
                                {
                                    ypaAdSlotId : "Search",
                                    ypaAdDivId  : "ypaAdWrapper-Search",
                                    ypaAdWidth  : "600",
                                    ypaAdHeight : "996"
                                },
                            ]   
                        }); 
    
</script>

            [/CBC]'.'[CBC show="y" country="cl"]
 
          
<!--Insert the code below after any div.-->
   
<script type="text/javascript">
                        window.ypaAds.insertMultiAd({
                            ypaAdConfig   : "0000004f7",
                            ypaAdTypeTag  : "466",
                            ypaAdSlotInfo : [ 
                                {
                                    ypaAdSlotId : "Search",
                                    ypaAdDivId  : "ypaAdWrapper-Search",
                                    ypaAdWidth  : "600",
                                    ypaAdHeight : "996"
                                },
                            ]   
                        }); 
    
</script>

            [/CBC]'.'[CBC show="y" country="br"]
             <style>#ypaAdWrapper-Search iframe{width:100%}</style>
            <script type="text/javascript">
                        window.ypaAds.insertMultiAd({
                           window.ypaAds.insertMultiAd({
                            ypaAdConfig   : "00000051f",
                            ypaAdTypeTag  : "",
                            ypaAdSlotInfo : [ 
                                {
                                    ypaAdSlotId : "Search",
                                    ypaAdDivId  : "ypaAdWrapper-Search",
                                    ypaAdWidth  : "600",
                                    ypaAdHeight : "1002"
                                }
                            ]   
                        }); 
</script>[/CBC]'.'[CBC show="n" country="mx, ve, pe, co, cl, br"]
 
         
<!--Insert the code below after any div.-->
    
<script type="text/javascript">
                        window.ypaAds.insertMultiAd({
                            ypaAdConfig   : "0000004f3",
                            ypaAdTypeTag  : "",
                            ypaAdSlotInfo : [ 
                                {
                                    ypaAdSlotId : "Search",
                                    ypaAdDivId  : "ypaAdWrapper-Search",
                                    ypaAdWidth  : "600",
                                    ypaAdHeight : "996"
                                },
                            ]   
                        }); 
    
</script>

            [/CBC]') ?>
        
        
        
        
        

    <?php if($mkt==''){ ?>
    
    <div style="display:none; height:1px;"><vc:block data-affid="181820" data-width="627" data-height="200" data-term="<?php echo get_search_query();?>" id="wideTopVCblock" data-lat="yes" data-groupOrder="1"> </vc:block></div>
				<script src="http://feed.validclick.com/js/validclick-master.js"></script>
                
	<?php } ?>
	<?php
    if(isset($top_ads))
	{
		
		echo "<div class='vz_ads_div'>";
		echo "<div class='vz_heading'>Sponsored Listing</div>";		
		foreach ($top_ads as $ad)
		{
			echo $ad;
		}
		echo  "</div>";
		
	}
	?>	
    
    
		<?php 
		
		//Main search Content
		get_template_part('loop', 'archive'); ?>
        
        <?php
		if(isset($top_ads))
		{
			echo "<div class='vz_ads_div'>";
			echo "<div class='vz_heading'>Sponsored Listing</div>";	
			foreach ($top_ads as $ad)
			{
				echo $ad;
			}
			echo  "</div>";
			
		}
		?>
	</div><!-- end #content -->
	
	<div id="side">
	
		<?php get_sidebar(); ?>
	
	</div><!-- end #side -->
	
	<div class="cleaner">&nbsp;</div>

	<?php get_template_part('footer-widgets'); ?>
	 
</div><!-- end .wrapper -->

<?php get_footer(); ?>