<style>



@charset "utf-8";



/* CSS Document */







.vz_ads_div {



    background: none repeat scroll 0 0 #EEF5FF;



    border: 1px solid #E3E3E3;



    font-family: arial;



    margin-bottom: 15px;



}



.vz_ads_div > a:hover {



    text-decoration: none;



}







.vz_heading {



    color: #ED1B24;



    font-size: 11px;



    font-weight: bold;



    padding:10px 10px 0;



}











.vz_ad_div {



   padding: 10px;



}







.vz_ad_title {



    border-bottom: 1px solid #D3DBE8;



    color: #0D0D0D;



    font-size: 14px;



    padding: 5px 0;



}











.vz_ad_desc {



    color: #595959;



    font-size: 12px;



    padding: 5px 0;



}











.vz_ad_url {



    color: #ED1B24;



    font-size: 11pt;



}



</style>



<?php 







require_once './feed/callFeed.php';



$country = getCountryByIpAddress($_SERVER['REMOTE_ADDR']);







$allowedCountries = array('my', 'vn', 'th', 'ph', 'id', 'sg', 'in', 'mx', 'ar', 've', 'pe', 'co', 'cl');



if (in_array($country, $allowedCountries))



{



		$mkt = $country;



}



else 



{



	$mkt ='';



}











get_header();



if ($query = get_search_query())



{



	if($mkt !='')



	{



		$ads = callFeed($query,'','','',6,'', '', 'fromsearchbox'); 



	}	



	?>



    <style type="text/css">



	.vz_ads_div {background: none repeat scroll 0 0 #FFFBEA;border: 1px solid #EFE9D1;}



	.vz_ads_div > a:hover {	text-decoration: none;}



	.vz_heading {color: #494949;font-size: 11px;font-weight: bold;padding:10px 10px 0;}



	.vz_ad_div {padding: 10px;}



	.vz_ad_title {color: #CC333F;font-size: 18px;text-decoration: underline;}



	.vz_ad_desc {color: #3D3D3D;font-size: 12px;padding: 10px 0;}



	.vz_ad_url {color: #467305;font-size: 11pt;}



	.related_word {padding:10px;color:#3d3d3d;}



	.related_word span {color:#e56c69;font-size:15px;}



	.related_word a {color:#e56c69;font-size:15px;}



	.related_word a:hover {color: #AC3633;}



	</style>



    



    <?php



	if ($ads)



	{



		$i=1;



		foreach($ads as $ad)



		{



			if($i<=3)



			{



				$top_ads[] = "<a href='" . $ad[AD_URL] . "' target='_blank'><div class='vz_ad_div'><div class='vz_ad_title'>". strip_tags($ad[AD_TITLE]) . "</div><div class='vz_ad_desc'>". strip_tags($ad[AD_DESCRIPTION]) . "</div><div class='vz_ad_url'>" . $ad[AD_SITE] . "</div></div></a>";



				$i++;



			}				



			else if($i >= 4)	



			{



				$bottom_ads[] = "<a href='" . $ad[AD_URL] . "' target='_blank'><div class='vz_ad_div'><div class='vz_ad_title'>". strip_tags($ad[AD_TITLE]) . "</div><div class='vz_ad_desc'>". strip_tags($ad[AD_DESCRIPTION]) . "</div><div class='vz_ad_url'>" . $ad[AD_SITE] . "</div></div></a>";



				$i++;



			}



		}



	}



	



	



}



?>



<div class="wrapper">



<!--INFOLINKS_OFF-->



		<section id="primary" class="site-content">





    



	<?php



    if(isset($top_ads))



	{



		



		echo "<div class='vz_ads_div'>";



		echo "<div class='vz_heading'>Sponsored Listing</div>";		



		foreach ($top_ads as $ad)



		{



			echo $ad;



		}



		echo  "</div>";



		



	}



	?>	



    




		<div id="content" role="main">



<div id="ypaAdWrapper-Search"></div>



<?php echo do_shortcode('[CBC show="y" country="mx"]
 
         
<!--Insert the code below after any div.-->
    
<script type="text/javascript">
                        window.ypaAds.insertMultiAd({
                            ypaAdConfig   : "0000004a9",
                            ypaAdTypeTag  : "479",
                            ypaAdSlotInfo : [ 
                                {
                                    ypaAdSlotId : "Search",
                                    ypaAdDivId  : "ypaAdWrapper-Search",
                                    ypaAdWidth  : "600",
                                    ypaAdHeight : "996"
                                },
                            ]   
                        }); 
    
</script>

            [/CBC]'.'[CBC show="y" country="ve"]
 
          
<!--Insert the code below after any div.-->
  
<script type="text/javascript">
                        window.ypaAds.insertMultiAd({
                            ypaAdConfig   : "0000004a9",
                            ypaAdTypeTag  : "481",
                            ypaAdSlotInfo : [ 
                                {
                                    ypaAdSlotId : "Search",
                                    ypaAdDivId  : "ypaAdWrapper-Search",
                                    ypaAdWidth  : "600",
                                    ypaAdHeight : "996"
                                },
                            ]   
                        }); 
    
</script>

            [/CBC]'.'[CBC show="y" country="pe"]
 
          
<!--Insert the code below after any div.-->
    
<script type="text/javascript">
                        window.ypaAds.insertMultiAd({
                            ypaAdConfig   : "0000004a9",
                            ypaAdTypeTag  : "482",
                            ypaAdSlotInfo : [ 
                                {
                                    ypaAdSlotId : "Search",
                                    ypaAdDivId  : "ypaAdWrapper-Search",
                                    ypaAdWidth  : "600",
                                    ypaAdHeight : "996"
                                },
                            ]   
                        }); 
    
</script>

            [/CBC]'.'[CBC show="y" country="co"]
 
          
<!--Insert the code below after any div.-->
    
<script type="text/javascript">
                        window.ypaAds.insertMultiAd({
                            ypaAdConfig   : "0000004a9",
                            ypaAdTypeTag  : "483",
                            ypaAdSlotInfo : [ 
                                {
                                    ypaAdSlotId : "Search",
                                    ypaAdDivId  : "ypaAdWrapper-Search",
                                    ypaAdWidth  : "600",
                                    ypaAdHeight : "996"
                                },
                            ]   
                        }); 
    
</script>

            [/CBC]'.'[CBC show="y" country="cl"]
 
          
<!--Insert the code below after any div.-->
   
<script type="text/javascript">
                        window.ypaAds.insertMultiAd({
                            ypaAdConfig   : "0000004a9",
                            ypaAdTypeTag  : "484",
                            ypaAdSlotInfo : [ 
                                {
                                    ypaAdSlotId : "Search",
                                    ypaAdDivId  : "ypaAdWrapper-Search",
                                    ypaAdWidth  : "600",
                                    ypaAdHeight : "996"
                                },
                            ]   
                        }); 
    
</script>

            [/CBC]'.'[CBC show="y" country="br"]
 
          
<!--Insert the code below after any div.-->
                       <script type="text/javascript">
                        window.ypaAds.insertMultiAd({
                            ypaAdConfig   : "000000520",
                            ypaAdTypeTag  : "",
                            ypaAdSlotInfo : [ 
                                {
                                    ypaAdSlotId : "Search",
                                    ypaAdDivId  : "ypaAdWrapper-Search",
                                    ypaAdWidth  : "600",
                                    ypaAdHeight : "1002"
                                }
                            ]   
                        }); 
</script>[/CBC]'.'[CBC  show="n" country="mx, ve, pe, co, cl, br"]
 
         
<!--Insert the code below after any div.-->
    
<script type="text/javascript">
                        window.ypaAds.insertMultiAd({
                            ypaAdConfig   : "0000004a9",
                            ypaAdTypeTag  : "479",
                            ypaAdSlotInfo : [ 
                                {
                                    ypaAdSlotId : "Search",
                                    ypaAdDivId  : "ypaAdWrapper-Search",
                                    ypaAdWidth  : "600",
                                    ypaAdHeight : "996"
                                },
                            ]   
                        }); 
    
</script>

            [/CBC]'); ?>


		<?php if ( have_posts() ) : ?>







			<header class="page-header">



				<h1 class="page-title"><?php printf( __( 'Search Results for: %s', 'womendisease' ), '<span>' . get_search_query() . '</span>' ); ?></h1>



			</header>







			<?php womendisease_content_nav( 'nav-above' ); ?>







			<?php /* Start the Loop */ ?>



			<?php while ( have_posts() ) : the_post(); ?>



				<?php get_template_part( 'content', get_post_format() ); ?>



			<?php endwhile; ?>







			<?php womendisease_content_nav( 'nav-below' ); ?>







		<?php else : ?>







			<article id="post-0" class="post no-results not-found">



				<header class="entry-header">



					<h1 class="entry-title"><?php _e( 'Nothing Found', 'womendisease' ); ?></h1>



				</header>







				<div class="entry-content">



					<p><?php _e( 'Sorry, but nothing matched your search criteria. Please try again with some different keywords.', 'womendisease' ); ?></p>



					<?php get_search_form(); ?>



				</div><!-- .entry-content -->



			</article><!-- #post-0 -->







		<?php endif; ?>







		</div>



        



        <?php



		if(isset($bottom_ads))



		{



			echo "<div class='vz_ads_div'>";



			echo "<div class='vz_heading'>Sponsored Listing</div>";	



			foreach ($bottom_ads as $ad)



			{



				echo $ad;



			}



			echo  "</div>";



			



		}



		?>



	</section><!-- end #content -->



	



	



	<?php get_sidebar(); ?>



<?php get_footer(); ?>