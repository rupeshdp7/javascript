<?php



/**



 * The Header template for our theme



 *



 * Displays all of the <head> section and everything up till <div id="main">



 *



 * @package WordPress



 * @subpackage Women_Disease



 * @since Women Disease 1.0



 */



?>

<!DOCTYPE html>



<!--[if IE 7]>



<html class="ie ie7" <?php language_attributes(); ?>>



<![endif]-->



<!--[if IE 8]>



<html class="ie ie8" <?php language_attributes(); ?>>



<![endif]-->



<!--[if !(IE 7) | !(IE 8)  ]><!-->



<html <?php language_attributes(); ?>>



<!--<![endif]-->



<head>

<meta charset="<?php bloginfo( 'charset' ); ?>" />

<title>

<?php wp_title( '|', true, 'right' ); ?>

</title>

<link rel="profile" href="http://gmpg.org/xfn/11" />

<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />





<?php // Loads HTML5 JavaScript file to add support for HTML5 elements in older IE versions. ?>



<!--[if lt IE 9]>



<script src="<?php echo get_template_directory_uri(); ?>/js/html5.js" type="text/javascript"></script>



<![endif]-->



<?php wp_head(); ?>

<script type="text/javascript">



jQuery(document).ready(function(){

	jQuery(".widget_rss h3 a.rsswidget:first-child").remove();

	jQuery(".widget_rss a").attr('target', '_blank');

	jQuery(".widget_rss a").removeAttr("title");

});



</script>


<script src='https://s.yimg.com/uv/dm/scripts/syndication.js'></script>



</head>



<body <?php body_class(); ?>>

<!--<div class="topbar">

      <div class="ctnr">

      	<div class="txrt">

        	<a href="http://getstronghealth.com/" target="_blank"><img src="<?php echo get_bloginfo('template_directory');?>/images/logo-1.png"></a><a href="http://www.healthnadvise.com/" target="_blank"><img src="<?php echo get_bloginfo('template_directory');?>/images/logo-2.png"></a><img src="<?php echo get_bloginfo('template_directory');?>/images/logo-3.png"><a href="http://dealwithcancer.com/" target="_blank"><img src="<?php echo get_bloginfo('template_directory');?>/images/logo-4.png"></a>

        </div>

      </div>

  </div>-->



<div id="page" class="hfeed site">

<header id="masthead" class="site-header" role="banner">

  <div class="logoarea">

    <div class="site-title logo"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><img src="<?php bloginfo( 'template_directory' ); ?>/images/logo.gif"></a></div>

    <div class="ad_header">

      <?php if ( is_active_sidebar( 'header_ad' ) ) : ?>

      <?php dynamic_sidebar( 'header_ad' ); ?>

      <?php endif; ?>

    </div>

  </div>

  <nav id="site-navigation" class="main-navigation" role="navigation">

   	<?php wp_nav_menu( array( 'theme_location' => 'primary', 'menu_class' => 'nav-menu' ) ); ?>

  </nav>

  <!-- #site-navigation --> 

  

  <?php if ( get_header_image() ) : ?>

  <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php header_image(); ?>" class="header-image" width="<?php echo get_custom_header()->width; ?>" height="<?php echo get_custom_header()->height; ?>" alt="" /></a>

  <?php endif; ?>

</header>

<!-- #masthead -->

<?php if(is_front_page()) { ?>

<?php } else { ?>

	<div class="breadcrumbs">

    <?php if(function_exists('bcn_display'))

    {

        bcn_display();

    }?>

</div>

<?php } ?>

<div id="main" class="wrapper">