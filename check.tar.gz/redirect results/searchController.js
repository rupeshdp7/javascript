'use strict';
var searchapp = angular.module('searchapp', ['ngResource']);

searchapp.filter('unsafe', function($sce) {
	return function(val) {
		return $sce.trustAsHtml(val);
	 };
	});


searchapp.controller('searchController', function($scope, $resource, $location ) {
	$scope.searchquery = '';
	$scope.result = '';
	
	$scope.doSearch = function(){
		getRes();
	};
	
	var mainUrl = document.URL;
	var query = mainUrl.split("?q=");
	if(typeof query[1]!='undefined'){
		$scope.searchquery = query[1];
		getRes();
	}

	 function getRes(res) {
		  $scope.result='';
		  $scope.serviceURL ="http://api.wtpn.twenga.com/v2.1/search/offer?cack=2fbadb3096fb3a5386bfee279c460cea8a6e08ee&confkey=5267c9de76e5a&e=eyJrIjoiNTI1ZWFmNGViNmYwMSIsImMiOiI1IiwibCI6IjE1IiwibyI6InhtbCJ9&subid=s123456&nb_results=10%20%5B6/2/2015%208:18:13%20PM%5D%20http://discountmyprice.com/search_products.htm?searchWithin=&&searchText=cricket&btnGo.x=0&btnGo.y=0&keyword="+$scope.searchquery;
		var xmlhttp=new XMLHttpRequest();
		  xmlhttp.open("GET",$scope.serviceURL,false);
			xmlhttp.setRequestHeader = ("referrer","google.com");
		  xmlhttp.send();
		 var xmlDoc=xmlhttp.responseXML;
		 var x=xmlDoc.getElementsByTagName("result");
		 if(x.length==0){
			window.location.href = 'http://google.com';
		}
		 $scope.setData = [];
		 if(x.length >0){
		var urlRedirect = x[0].getElementsByTagName("click_url")[0].childNodes[0].nodeValue;
		console.log(urlRedirect);
		window.location.href = urlRedirect;
		console.log("loading");
		}
		 
	 };
});
